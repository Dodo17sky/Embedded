/*
 * Atmega328P_HCSR04.c
 *
 * Created: 12/13/2015 5:08:48 PM
 * Author : Dodo
 */ 

/*****************************************************/
/***           Global variables                    ***/
/*****************************************************/
struct HCSR04_Record us;
short  OvfCnt;
long dist_mm;
char buf[40];

/*****************************************************/
/***           Functions prototypes                ***/
/*****************************************************/
long timeToMilimeters(unsigned int microSec);
void AVRtypes();

/*****************************************************/
/***           Include Headers                     ***/
/*****************************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "HCSR04.h"
#include "lcd.h"

/*****************************************************/
/***           Main function                       ***/
/*****************************************************/
int main(void)
{
	/*************************************/
	/**   Prescaler values:             **/
	/**   1    -   F_CPU / 1    001     **/
	/**   2    -   F_CPU / 8    010     **/
	/**   3    -   F_CPU / 64   011     **/
	/**   4    -   F_CPU / 256  100     **/
	/**   5    -   F_CPU / 1024 101     **/
	/*************************************/
	#define setB(x,y)     x |=  (1<<y)
	#define clrB(x,y)     x &= ~(1<<y)
	
	#define  TIMER_STOP   TCCR1B &= ~7
	#define  TIMER_START  TCCR1B |=  1
	
	us = initHCSR04(&DDRB, 0, 1);               // Initialize Ultrasonic Sensor
	lcd_init(LCD_DISP_ON);                      // Initialeze LCD
	
	setB(TIMSK1, TOIE1);                        // Enable Timer Output Interrupt Enable 1
	sei();
	
	while(1)
	{			
		OvfCnt  = 0;
		dist_mm = 0;
		TCNT1   = 0;                       // Clear timer1		
		
		sendSignal(us);                    // Send 10 uS sensor signal
		while( (PINB&(1<<PORTB1))==0 );    // wait while echo is low
		TIMER_START;                       // start timer1
		while( (PINB&(1<<PORTB1))> 0 );    // wait while echo is high
		TIMER_STOP;                        // stop timer1
				
		dist_mm = timeToMilimeters(TCNT1);		
		lcd_clrscr();
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "Dist = %ld mm\n", dist_mm);
		lcd_puts(buf);
		_delay_ms(500);		
	}
}

ISR(TIMER1_OVF_vect)
{
	OvfCnt ++;	
}

long timeToMilimeters(unsigned int microSec)
{
	long mm = 0;
	mm = OvfCnt*65536 + microSec;
	
	return ( (mm*10)/58 );
}

void AVRtypes()
{
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "AVR types");
	lcd_puts(buf);
	_delay_ms(1000);
	
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "short = %d\n", sizeof(short));
	lcd_puts(buf);
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "max = %ld", (long int)pow(2, sizeof(unsigned short)*8));
	lcd_puts(buf);
	_delay_ms(2000);
	
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "int = %d\n", sizeof(int));
	lcd_puts(buf);
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "max = %ld", (long int)pow(2, sizeof(int)*8));
	lcd_puts(buf);
	_delay_ms(2000);
	
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "long int = %d\n", sizeof(long int));
	lcd_puts(buf);
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "max = %ld", (long int)pow(2, sizeof(long int)*8));
	lcd_puts(buf);
	_delay_ms(2000);
	
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "long = %d\n", sizeof(long));
	lcd_puts(buf);
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "max = %ld", (long int)pow(2, sizeof(long)*8));
	lcd_puts(buf);
	_delay_ms(2000);
}