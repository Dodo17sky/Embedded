/*
 * Atmega328P_LCD.c
 *
 * Created: 12/20/2015 6:35:44 PM
 * Author : Dodo
 */ 

#define  F_CPU         1000000UL
#define  setB(x,y)     x |=  (1<<y)
#define  clrB(x,y)     x &= ~(1<<y)
#define  TIMER_STOP   TCCR1B &= ~7
#define  TIMER_START  TCCR1B |=  1

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#include "lcd.h"
#include "HCSR04.h"

struct HCSR04_Record us;
short  OvfCnt;
long   dist_mm;
char   buf[40];

int  mapping(int valS, int minS, int maxS, int minD, int maxD);
long timeToMilimeters(unsigned int microSec);
short displayScale(long dist);
void LCD_test00();
void LCD_test01();
void LCD_test02();
void LCD_test03();

int main(void)
{
    LCD_test03();
}

void LCD_test00(){
	lcd_init(LCD_DISP_ON);
	lcd_clrscr();
	lcd_puts("This is a test");
}

void LCD_test01(){
	lcd_init(LCD_DISP_ON);
	lcd_clrscr();
	lcd_puts("This is a test\n");
	
	lcd_gotoxy(5, 1);
	lcd_puts("####");
}

void LCD_test02(){
	int i = 0;
	int j = 0;
	int step = 0;
	
	lcd_init(LCD_DISP_ON);
	
	while(1)
	{
		i += step;
		
		lcd_clrscr();
		memset(buf, 0, sizeof(buf));
		for(j=0; j<i; j++)
			strcat(buf, "#");
						
		lcd_puts( buf );	
		_delay_ms(100);
		
		if(i==0)
			step = 1;
		if(i==16)
			step = -1;
	}
}

//
// LCD display the distance take by HCSR04 in two modes:
//   - a scale bar 
//   - display text
void LCD_test03(){
	lcd_init(LCD_DISP_ON);
	us = initHCSR04(&DDRB, 0, 1);
	lcd_clrscr();
	
	setB(TIMSK1, TOIE1);                        // Enable Timer Output Interrupt Enable 1
	sei();
	
	int x   = 0;
	int dst = 0;
	
	while(1)
	{
		for(x=0; x<20; x++)
		{
			OvfCnt  = 0;
			dist_mm = 0;
			TCNT1   = 0;                       // Clear timer1
		
			sendSignal(us);                    // Send 10 uS sensor signal
			while( (PINB&(1<<PORTB1))==0 );    // wait while echo is low
			TIMER_START;                       // start timer1
			while( (PINB&(1<<PORTB1))> 0 );    // wait while echo is high
			TIMER_STOP;                        // stop timer1
			dist_mm = timeToMilimeters(TCNT1);
			dst += dist_mm;
		}
		
		dst /= 20;
		
		displayScale(dst);		
		
		_delay_ms(3);
	}
}

ISR(TIMER1_OVF_vect)
{
	OvfCnt ++;
}

long timeToMilimeters(unsigned int microSec)
{
	long mm = 0;
	mm = OvfCnt*65536 + microSec;
	
	return ( (mm*10)/58 );
}

int mapping(int valS, int minS, int maxS, int minD, int maxD)
{
	int intervalS = maxS - minS;
	int intervalD = maxD - minD;
	double map = 0.0;

	map = (double)valS/intervalS;
	map = (double)map*intervalD;

	return (int)(map);
}

short displayScale(long i)
{
	int j   = 0;
	int val = 0;
	
	if( i<20 || i>1600 )
		return 0;
	
	val = mapping(i, 0, 1600, 0, 16);
	
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	for(j=0; j<val; j++)
		strcat(buf, "#");
	lcd_puts( buf );
	
	memset(buf, 0, sizeof(buf));
	for(j=0; j<val; j++)
		sprintf(buf, "Dist = %ld", i);
	lcd_gotoxy(0, 1);
	lcd_puts( buf );
	_delay_ms(100);
	
	return 0;
}