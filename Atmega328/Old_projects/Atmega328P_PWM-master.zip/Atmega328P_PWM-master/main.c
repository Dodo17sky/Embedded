/*
 * Atmega328P_PWM.c
 *
 * Created: 12/13/2015 11:05:38 PM
 * Author : Dodo
 */ 

#define F_CPU 1000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "lcd.h"
#include "pwm.h"

void pwm_test0();
void pwm_test1();
void pwm_test2();
void pwm_test3();
double mapping(int valX, int minX, int maxX, int minA, int maxA);

#define setB(x,y)    x |=  (1<<y)
#define clrB(x,y)    x &= ~(1<<y)

int main(void)
{
	pwm_test3();
}

void pwm_test0() 
{
	/**
	 * We will be using OCR1A as our PWM output which is the
	 * same pin as PB1.
	 */
	setB(DDRB, PORTB1);

	/**
	 * There are quite a number of PWM modes available but for the
	 * sake of simplicity we'll just use the 8-bit Fast PWM mode.
	 * This is done by setting the WGM10 and WGM12 bits.  We 
	 * Setting COM1A1 tells the microcontroller to set the 
	 * output of the OCR1A pin low when the timer's counter reaches
	 * a compare value (which will be explained below).  CS10 being
	 * set simply turns the timer on without a prescaler (so at full
	 * speed).  The timer is used to determine when the PWM pin should be
	 * on and when it should be off.
	 */
	setB(TCCR1A, WGM10);
	setB(TCCR1A, COM1A1);
	setB(TCCR1B, WGM12);
	setB(TCCR1B, CS10);
	
	/**
	 *  This loop is used to change the value in the OCR1A register.
	 *  What that means is we're telling the timer waveform generator
	 *  the point when it should change the state of the PWM pin.
	 *  The way we configured it (with _BV(COM1A1) above) tells the
	 *  generator to have the pin be on when the timer is at zero and then
	 *  to turn it off once it reaches the value in the OCR1A register.
	 *
	 *  Given that we are using an 8-bit mode the timer will reset to zero
	 *  after it reaches 0xff, so we have 255 ticks of the timer until it
	 *  resets.  The value stored in OCR1A is the point within those 255
	 *  ticks of the timer when the output pin should be turned off
	 *  (remember, it starts on).
	 *
	 *  Effectively this means that the ratio of pwm / 255 is the percentage
	 *  of time that the pin will be high.  Given this it isn't too hard
	 *  to see what when the pwm value is at 0x00 the LED will be off
	 *  and when it is 0xff the LED will be at its brightest.
	 */
	uint8_t pwm = 0x00;
	bool up = true;
	for(;;) 
	{
		OCR1A = pwm;

		pwm += up ? 1 : -1;
		
		if (pwm == 0xff)
			up = false;
		else if (pwm == 0x00)
			up = true;

		_delay_ms(10);
	}

}

void pwm_test1() 
{
	setB(DDRB, PORTB1);

	setB(TCCR1A, WGM10);
	setB(TCCR1A, COM1A1);
	setB(TCCR1B, WGM12);
	setB(TCCR1B, CS10);
	
	uint8_t pwm = 0x00;
	short   step = 0;
		
	for(;;) 
	{
		pwm += step;
		OCR1A = pwm;
		
		if (pwm == 0xff){
			step = -1;
			_delay_ms(1000);
		}
		else if (pwm == 0x00){
			step = 1;
			_delay_ms(1000);
		}
			
		_delay_ms(30);
	}

}

void pwm_test2()
{
	setB(DDRB, PORTB1);

	setB(TCCR1A, WGM10);
	setB(TCCR1A, COM1A1);
	setB(TCCR1B, WGM12);
	setB(TCCR1B, CS10);
	
	lcd_init(LCD_DISP_ON);
	
	uint8_t pwm = 0x00;
	short   step = 10;
	float voltage = 0.0;
	char buf[17] = {0,};
	char val[20] = {0,};
	
	for(;;)
	{
		pwm += step;
		OCR1A = pwm;
		
		if (pwm == 250){
			step = -10;
			_delay_ms(1000);
		}
		else if (pwm == 0x00){
			step = 10;
			_delay_ms(1000);
		}
		
		voltage = mapping((int)pwm, 0, 255, 0, 5);
		memset(buf, 0, sizeof(buf));
		memset(val, 0, sizeof(buf));
		
		dtostrf(voltage, 5, 2, val);
		sprintf(buf,"Voltage:%s", val);		
		lcd_clrscr();
		lcd_puts(buf);
			
		_delay_ms(400);
	}

}

double mapping(int valS, int minS, int maxS, int minD, int maxD)
{
	int intervalS = maxS - minS;
	int intervalD = maxD - minD;
	double map = 0.0;

	map = (double)valS/intervalS;
	map = (double)map*intervalD;

	return (map);
}

void pwm_test3()
{
	pwm_initPortB(PORTB1);
	lcd_init(LCD_DISP_ON);
	
	uint8_t pwm = 0x00;
	short   step = 10;
	float voltage = 0.0;
	char buf[17] = {0,};
	char val[20] = {0,};
	
	for(;;)
	{
		pwm += step;
		pwm_set(pwm);
		
		if (pwm == 250){
			step = -10;
			memset(buf, 0, sizeof(buf));
			sprintf(buf,"PWM is at 250");
			lcd_clrscr();
			lcd_puts(buf);
			_delay_ms(2000);
		}
		else if (pwm == 0x00){
			step = 10;
			memset(buf, 0, sizeof(buf));
			sprintf(buf,"PWM is at 0");
			lcd_clrscr();
			lcd_puts(buf);
			_delay_ms(2000);
		}
		
		voltage = mapping((int)pwm, 0, 255, 0, 5);
		memset(buf, 0, sizeof(buf));
		memset(val, 0, sizeof(buf));
		
		dtostrf(voltage, 5, 2, val);
		sprintf(buf,"Voltage:%s", val);
		lcd_clrscr();
		lcd_puts(buf);
		
		_delay_ms(400);
	}

}
