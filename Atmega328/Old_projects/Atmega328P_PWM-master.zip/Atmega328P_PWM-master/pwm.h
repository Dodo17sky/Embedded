/*
 * pwm.h
 *
 * Created: 12/21/2015 12:54:30 PM
 *  Author: Dodo
 */ 


#ifndef PWM_H_
#define PWM_H_

short pwm_initPortD(uint8_t pin);
short pwm_initPortB(uint8_t pin);
short pwm_set(uint8_t pwm);


#endif /* PWM_H_ */