/*
 * TimerDemo.c
 *
 * Created: 12/12/2015 2:40:53 PM
 * Author : Dodo
 */ 

#define F_CPU 1000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include "lcd.h"

long t4  = 0;

/***********************************/
/**      TEST Functions           **/
/***********************************/
void timer00();
void timer01();
void timer02();
void timer03();
void timer04();
void timer05();
void timer06();

int main(void)
{
	timer06();
}

/** Start:  Test #1   **/
void timer00()
{
		
	/*************************************/
	/**   Prescaler values:             **/
	/**   1    -   F_CPU / 1    001     **/
	/**   2    -   F_CPU / 8    010     **/
	/**   3    -   F_CPU / 64   011     **/
	/**   4    -   F_CPU / 256  100     **/
	/**   5    -   F_CPU / 1024 101     **/
	/*************************************/
	
	/***    TIMER 8 bit resolution     ***/

	#define TIMER_START TCCR0B |=  (2)
	#define TIMER_STOP  TCCR0B &= ~(7)
	unsigned long i = 0;
	char buf[17] = {0,};
		
	lcd_init(LCD_DISP_ON);
		
	while (1)
	{
		TIMER_START;
			
		while(TCNT0<248);
		//=========================================
		TIMER_STOP;
		i++;
		lcd_clrscr();     /* clear display home cursor */
			
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "TCNT0 = %d\n", TCNT0);
		lcd_puts(buf);
			
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "Error = %d", TCNT0-248);
		lcd_puts(buf);

		_delay_ms(2000);
		TCNT0 = 0;
		//=========================================
		lcd_clrscr();     /* clear display home cursor */
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "Start counting");
		lcd_puts(buf);
		_delay_ms(1500);
	}
}
/** End:  Test #1     **/

/** Start:  Test #2   **/
void timer01()
{
		
	/*************************************/
	/**   Prescaler values:             **/
	/**   1    -   F_CPU / 1    001     **/
	/**   2    -   F_CPU / 8    010     **/
	/**   3    -   F_CPU / 64   011     **/
	/**   4    -   F_CPU / 256  100     **/
	/**   5    -   F_CPU / 1024 101     **/
	/*************************************/
	
	/***    TIMER 8 bit resolution     ***/
	
	#define TIMER_START TCCR0B |=  (4)
	#define TIMER_STOP  TCCR0B &= ~(7)
	
	#define SECCNT 15
	
	unsigned long i = 0;
	char buf[17] = {0,};
		
	lcd_init(LCD_DISP_ON);
		
	while (1)
	{
		TIMER_START;
			
		while(TCNT0<248);
		
		TIMER_STOP;
		TCNT0 = 0;
		i++;		
		//=========================================
		
		if( i % (SECCNT*2) == 0 )
		{
			lcd_clrscr();     /* clear display home cursor */
			memset(buf, 0, sizeof(buf));
			sprintf(buf, "i = %ld\n", i);
			lcd_puts(buf);
			
			memset(buf, 0, sizeof(buf));
			sprintf(buf, "c=%ld  r=%ld", (long)i/SECCNT, (long)i%SECCNT);
			lcd_puts(buf);
		}
	}
}
/** End:  Test #2     **/

/** Start:  Test #3   **/
void timer02()
{
	/*************************************/
	/**   Prescaler values:             **/
	/**   1    -   F_CPU / 1    001     **/
	/**   2    -   F_CPU / 8    010     **/
	/**   3    -   F_CPU / 64   011     **/
	/**   4    -   F_CPU / 256  100     **/
	/**   5    -   F_CPU / 1024 101     **/
	/*************************************/
	
	/***    TIMER 16 bit resolution     ***/
	
	#define TIMER_START TCCR1B |=  (1)
	#define TIMER_STOP  TCCR1B &= ~(7)
		
	#define SECCNT 15
		
	unsigned long i = 0;
	char buf[17] = {0,};
		
	lcd_init(LCD_DISP_ON);
		
	while (1)
	{
		TIMER_START;
			
		while(TCNT1<65530);
			
		TIMER_STOP;
		TCNT1 = 0;
		i++;
		//=========================================
			
		if( i % SECCNT == 0 )
		{
			lcd_clrscr();     /* clear display home cursor */
			memset(buf, 0, sizeof(buf));
			sprintf(buf, "i = %ld\n", i);
			lcd_puts(buf);
				
			memset(buf, 0, sizeof(buf));
			sprintf(buf, "c=%ld  r=%ld", (long)i/SECCNT, (long)i%SECCNT);
			lcd_puts(buf);
		}
	}
}
/** End:  Test #3     **/

/** Start:  Test #4   **/
void timer03()
{
	/*************************************/
	/**   Prescaler values:             **/
	/**   1    -   F_CPU / 1    001     **/
	/**   2    -   F_CPU / 8    010     **/
	/**   3    -   F_CPU / 64   011     **/
	/**   4    -   F_CPU / 256  100     **/
	/**   5    -   F_CPU / 1024 101     **/
	/*************************************/
	
	/***    TIMER 16 bit resolution     ***/
	
	#define TIMER_START TCCR1B |=  (5)
	#define TIMER_STOP  TCCR1B &= ~(7)
	
	char buf[17] = {0,};
	
	lcd_init(LCD_DISP_ON);
	
	while (1)
	{
		lcd_clrscr();     /* clear display home cursor */
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "START :)");
		lcd_puts(buf);
		TIMER_START;
		while(TCNT1 < 9766);
		TIMER_STOP;
		
		lcd_clrscr();     /* clear display home cursor */
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "Elapse 10 sec\n");
		lcd_puts(buf);
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "TCNT1=%d", TCNT1);
		lcd_puts(buf);
		_delay_ms(2000);
		TCNT1 = 0;
	}
}
/** End:  Test #4     **/

/** Start:  Test #5   **/
void timer04()
{
	/********************************************************************
	 **   Prescaler values:             **                             **
	 **   1    -   F_CPU / 1    001     **     Testing CTC mode        **
	 **   2    -   F_CPU / 8    010     **                             **
	 **   3    -   F_CPU / 64   011     **                             **
	 **   4    -   F_CPU / 256  100     **                             **
	 **   5    -   F_CPU / 1024 101     **                             **
	 ********************************************************************/
	
	/***    TIMER 16 bit resolution     ***/
	
	#define TIMER_START TCCR1B |=  (5)
	#define TIMER_STOP  TCCR1B &= ~(7)
	
	long i       = 0;
	char buf[17] = {0,};
		
	TIMER_START;
	TCCR1B |= (1<<WGM12);
	OCR1A   = 2930;
	
	lcd_init(LCD_DISP_ON);
	lcd_clrscr();
	
	while (1)
	{
		if( TIFR1 & (1<<OCF1A) )
		{
			i += 3;
			memset(buf, 0, sizeof(buf));
			sprintf(buf, "CTC active\n");
			lcd_puts(buf);
			memset(buf, 0, sizeof(buf));
			sprintf(buf, "Time =  %ld", i);
			lcd_puts(buf);		
			_delay_ms(1000);
			lcd_clrscr();	
			TIFR1 |= (1<<OCF1A);			
		}
	}
}
/** End:  Test #5     **/

/** Start:  Test #6   **/
void timer05()
{
	/********************************************************************
	 **   Prescaler values:             **                             **
	 **   1    -   F_CPU / 1    001     **     Testing CTC mode        **
	 **   2    -   F_CPU / 8    010     **                             **
	 **   3    -   F_CPU / 64   011     **                             **
	 **   4    -   F_CPU / 256  100     **                             **
	 **   5    -   F_CPU / 1024 101     **                             **
	 ********************************************************************/
	
	/***    TIMER 16 bit resolution     ***/
	
	#define TIMER_START TCCR1B |=  (5)
	#define TIMER_STOP  TCCR1B &= ~(7)
		
	TIMER_START;               // Set Prescaler
	TCCR1B |= (1<<WGM12);      // Set CTC mode
	OCR1A   = 4883;            // Set compare value
	TIMSK1 |= (1<<OCIE1A);     // Enable CTC interrupts
	sei();                     // Enable global interrupts
	
	lcd_init(LCD_DISP_ON);
	lcd_clrscr();
	
	while (1)
	{
	}
}
ISR(TIMER1_COMPA_vect)
{
	char buf[17] = {0,};
	t4 += 5;
	lcd_clrscr();
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "CTC active\n");
	lcd_puts(buf);
	memset(buf, 0, sizeof(buf));
	sprintf(buf, "Time =  %ld", t4);
	lcd_puts(buf);
	TIFR1 |= (1<<OCF1A);
}
/** End:  Test #6     **/

/** Start:  Test #7   **/
void timer06()
{
	/********************************************************************
	 **   Prescaler values:             **                             **
	 **   1    -   F_CPU / 1    001     **     Testing CTC mode        **
	 **   2    -   F_CPU / 8    010     **         using               **
	 **   3    -   F_CPU / 64   011     **     Compare Output Mode     **
	 **   4    -   F_CPU / 256  100     **        COM1A0 COM1A1        **
	 **   5    -   F_CPU / 1024 101     **        COM1B0 COM1B1        **
	 ********************************************************************/
	
	/***    TIMER 16 bit resolution     ***/
	
	DDRB   |= (1<<PORTB1);     // Set LED as output
	DDRB   |= (1<<PORTB2);     // Set LED as output
	TCCR1B |= (1<<WGM12);      // Set CTC mode
	TCCR1A |= (1<<COM1A0);     // Set Compare Output Mode
	OCR1A   = 7812;            // Set compare value   |    prescaler + compare value  
	TCCR1B |=  (3);            // Set preScaler	      |    => toggle at 500 ms
	
	while (1) { }
}
/** End:  Test #7     **/