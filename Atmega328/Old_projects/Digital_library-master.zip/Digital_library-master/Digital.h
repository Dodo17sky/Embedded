/*
 * Digital.h
 *
 * Created: 12/6/2015 2:07:01 PM
 *  Author: Dodo
 */ 

#include <stdbool.h>

#ifndef DIGITAL_H_
#define DIGITAL_H_

/****************************************************/
/**   set DDRx pins states (IN or OUT)             **/
/****************************************************/
#define OUTPUT     1
#define INPUT      0
void setOut    (volatile uint8_t* ddr, uint8_t pin);
void setIn     (volatile uint8_t* ddr, uint8_t pin);
void setDDR    (volatile uint8_t* ddr, uint8_t pin, uint8_t type);

/****************************************************/
/**   set digital OUTPUT pin state                 **/
/****************************************************/
#define  HIGH   1
#define  LOW    0

void digitalH     (volatile uint8_t* port, uint8_t pin);
void digitalL     (volatile uint8_t* port, uint8_t pin);
void digitalWrite (volatile uint8_t* port, uint8_t pin, uint8_t state);

/****************************************************/
/**   get digital INPUT pin state                  **/
/****************************************************/
bool digitalRead  (volatile uint8_t* pinPort, uint8_t pin);

#endif /* DIGITAL_H_ */