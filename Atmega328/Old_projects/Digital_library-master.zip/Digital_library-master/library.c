/*
 * Digital_library.c
 *
 * Created: 12/6/2015 2:06:39 PM
 * Author : Dodo
 */ 

#include <avr/io.h>
#include "Digital.h"

/****************************************************/
/**   DDRx set OUT or IN pin prototypes            **/
/****************************************************/
void setOut(volatile uint8_t* ddr, uint8_t pin)
{
	*ddr |= (1<<pin);
}

void setIn (volatile uint8_t* ddr, uint8_t pin)
{
	*ddr &= ~(1<<pin);
	ddr++;
	*ddr |=  (1<<pin);
}

void setDDR(volatile uint8_t* ddr, uint8_t pin, uint8_t type)
{
	if (type==OUTPUT)
		*ddr |= (1<<pin);
	
	else if(type==INPUT )
	{
		*ddr &= ~(1<<pin);
		ddr++;
		*ddr |=  (1<<pin);
	}
}

/****************************************************/
/**   set OUTPUT PIN state                         **/
/****************************************************/
void digitalH(volatile uint8_t* port, uint8_t pin)
{
	*port |= (1<<pin);
}

void digitalL(volatile uint8_t* port, uint8_t pin)
{
	*port &= ~(1<<pin);
}

void digitalWrite(volatile uint8_t* port, uint8_t pin, uint8_t state)
{
	if(state==HIGH)
		*port |= (1<<pin);
	
	else if(state==LOW)
		*port &= ~(1<<pin);
}

/****************************************************/
/**   get digital INPUT pin state                  **/
/****************************************************/
bool digitalRead  (volatile uint8_t* pinPort, uint8_t pin)
{
	/**************************************************/
	/*   INPUT pins have a logic state 1 when         */
	/*   are initialized.                             */
	/*                                                */
	/*   If the pin get an input (button is pressed)  */
	/*   it means the pin is CLEAR, and PINx register */
	/*   should have a 0 logic state                  */
	/*                                                */
	/**************************************************/
	
	if( (*pinPort & (1<<pin))==LOW )
	//
		return true;   //  pin state LOW , ( button PRESSED )
	//
	
	if( (*pinPort & (1<<pin))==HIGH )
	//
		return false;  //  pin state HIGH, ( button NOT PRESSED )
	//
	
	return false;
}
