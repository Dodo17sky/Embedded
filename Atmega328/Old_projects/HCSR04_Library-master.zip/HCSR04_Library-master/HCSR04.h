/*
 * HCSR04.h
 *
 * Created: 12/6/2015 2:37:30 PM
 *  Author: Dodo
 */ 

#define F_CPU           1000000UL
#include <util/delay.h>

#ifndef HCSR04_H_
#define HCSR04_H_

#define Prescaler_1     1
#define Prescaler_8     8
#define Prescaler_64    64
#define Prescaler_256   256
#define Prescaler_1024  1024

struct HCSR04_Record
{
	volatile uint8_t * DDR;
	volatile uint8_t * PORT;
	volatile uint8_t * PIN;
	uint8_t trig;
	uint8_t echo;
};

struct HCSR04_Record  initHCSR04(volatile uint8_t * reg, uint8_t trig, uint8_t echo);
void   sendSignal(struct HCSR04_Record Sensor);

#endif /* HCSR04_H_ */