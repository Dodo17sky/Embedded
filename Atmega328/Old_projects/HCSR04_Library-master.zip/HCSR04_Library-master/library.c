/*
 * HCSR04_library.c
 *
 * Created: 12/6/2015 2:37:02 PM
 * Author : Dodo
 */ 

#include <avr/io.h>
#include "HCSR04.h"

struct HCSR04_Record  initHCSR04(volatile uint8_t * reg, uint8_t trig, uint8_t echo)
{
	struct HCSR04_Record newUS;
	newUS.DDR   = reg;
	newUS.PORT  = reg+1;
	newUS.PIN   = reg-1;
	newUS.trig  = trig;
	newUS.echo  = echo;
		
	*newUS.DDR  |=  (1<<newUS.trig);   // Set output trig pin  D2
	*newUS.DDR  &= ~(1<<newUS.echo);   // Set input  echo pin
	*newUS.PORT |=  (1<<newUS.echo);   // Set input  echo pin high
		
	return newUS;
}

void   sendSignal(struct HCSR04_Record Sensor)
{
	*Sensor.PORT &= ~(1 << Sensor.trig);
	_delay_us(1);
	*Sensor.PORT |=  (1 << Sensor.trig);
	_delay_us(15);
	*Sensor.PORT &= ~(1 << Sensor.trig);
}