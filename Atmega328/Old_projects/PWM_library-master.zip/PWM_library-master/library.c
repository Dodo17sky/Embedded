/*
 * PWM_library.c
 *
 * Created: 12/21/2015 12:48:07 PM
 * Author : Dodo
 */ 

#include <avr/io.h>
#include "pwm.h"

short pwm_initPortB(uint8_t pin)
{
	if(pin == PORTB1)
		DDRB |= (1<<PORTB1);
		
	if(pin == PORTB2)
		DDRB |= (1<<PORTB2);
		
	if(pin == PORTB3)
		DDRB |= (1<<PORTB3);
		
	TCCR1A |= (1<<WGM10);
	TCCR1A |= (1<<COM1A1);
	TCCR1B |= (1<<WGM12);
	TCCR1B |= (1<<CS10);
	
	return 0;
}

short pwm_initPortD(uint8_t pin)
{
	if(pin == PORTD3)
		DDRD |= (1<<PORTD3);
	
	if(pin == PORTD5)
		DDRD |= (1<<PORTD5);
	
	if(pin == PORTD6)
		DDRD |= (1<<PORTD6);
	
	TCCR1A |= (1<<WGM10);
	TCCR1A |= (1<<COM1A1);
	TCCR1B |= (1<<WGM12);
	TCCR1B |= (1<<CS10);
	
	return 0;
}

short pwm_set(uint8_t pwm)
{
	OCR1A = pwm;
	return 0;
}