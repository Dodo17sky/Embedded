/*
 * SCR_test.c
 *
 * Created: 1/14/2016 1:55:07 PM
 * Author : Dorin
 */

//
//     Includere biblioteci
//
#define  F_CPU         1000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "ShiftRegister.h"
#include "lcd.h" 
/////////////////////////////////////////////////


//
//      Variabila registru de deplasare
//  

struct ShiftRegister  sr;
////////////////////////////////////////////////////////

//
//  Variabile macro pentru CAN
// 
#define  AREF_AS_VCC            1
#define  AREF_FROM_PIN          2
#define  VALOARE_CUANTA_8BITI   0.01953

// Functii CAN
double   mapeaza(double valX, double oldMin, double oldMax, double newMin, double newMax);
uint16_t Citeste_CAN();
void     Initiaza_CAN(int mode);

int main(void)
{
	int  i                   = 0;
	char mesaj[100]          = {0,};
	char nrZecimalCaText[10] = {0,};
	unsigned long cuante_CAN = 0;        // Variable to hold ADC result
	double        voltaj     = 0.0;
	
	Initiaza_CAN(AREF_AS_VCC);
	lcd_init(LCD_DISP_ON);
	sr = initShiftRegister(&DDRB, 0, 1, 2);
	
	lcd_clrscr();
	lcd_puts("   START CAN");
	_delay_ms(2000);
	
	while (1)
	{
		cuante_CAN = 0;
		
		                                      //    Pentru o buna acuratete a conversiei se va calcula
		for(i=0; i<10; i++)                   //    media a 10 conversii analog-digitale consecutive
		{                                     
			ADCSRA |= (1<<ADSC);              //   Start conversie din analog in digital
			while(  (ADCSRA & (1<<ADSC))  );  //   Asteapta sfarsitul conversiei
			cuante_CAN += ADC;                //   Memoreaza valoarea cuantelor rezultate
			_delay_ms(5);
		}
		
		cuante_CAN /= 10;                    //    Se calculeaza valoarea medie a celor 10 conversii
		cuante_CAN /= 4;                     //    Conversia cuantelor din rezolutia de 10 biti in rezolutia de 8 biti
		
		
		
		lcd_clrscr();                        //    Se curata displayul LCD
		memset( mesaj, 0, sizeof(mesaj) );   //    Initializam cu valori nule, sirul ce contine mesajul de afisat pe LCD
		sprintf(mesaj, "Cuante = %ld\n", cuante_CAN );   //  Formatam mesajul pentru linia 1 a LCD-ului
		lcd_puts(mesaj);                                 //  Transmitem mesajul catre LCD
		
		voltaj = VALOARE_CUANTA_8BITI / 2 + cuante_CAN * VALOARE_CUANTA_8BITI;
		
		memset( nrZecimalCaText, 0, sizeof(nrZecimalCaText) );
		dtostrf( voltaj, 4, 2, nrZecimalCaText);
		
		memset( mesaj, 0, sizeof(mesaj) );
		sprintf(mesaj, "Voltaj = %s", nrZecimalCaText);
		lcd_puts(mesaj);
		_delay_ms(500);
		
		shiftByte(sr, cuante_CAN );
	}
}

void Initiaza_CAN(int mode)
{
	if( mode == AREF_AS_VCC   )  // Select Vref=AVcc
	{
		ADMUX |=  (1<<REFS0);
		ADMUX &= ~(1<<REFS1);
	}
	
	if( mode == AREF_FROM_PIN ) // Use input AREF voltage
	{
		ADMUX &= ~(1<<REFS0);
		ADMUX &= ~(1<<REFS1);
	}
	
	ADCSRA  = (1<<ADEN);               // Enable ADC
	ADCSRA |= (1<<ADPS1)|(1<<ADPS0);   //set prescaller to 8 and enable ADC
	ADMUX  |= (1<<MUX0);               // ADC input channel set to ADC1
}

uint16_t Citeste_CAN()
{
	// Select ADC channel
	ADMUX |=  (1<<MUX0);
	ADMUX &= ~(1<<MUX0) & ~(1<<MUX1) & ~(1<<MUX2) & ~(1<<MUX3);

	//Start Single conversion
	ADCSRA|=(1<<ADSC);

	//Wait for conversion to complete
	while(!(ADCSRA & (1<<ADIF)));

	//Clear ADIF by writing one to it
	//Note you may be wondering why we have write one to clear it
	//This is standard way of clearing bits in io as said in datasheets.
	//The code writes '1' but it result in setting bit to '0' !!!

	ADCSRA|=(1<<ADIF);

	return(ADC);
}

double mapeaza(double valX, double oldMin, double oldMax, double newMin, double newMax)
{
	double res    = 0;
	double oldInt = 0;
	double newInt = 0;
	
	oldInt = oldMax - oldMin;
	newInt = newMax - newMin;
	
	res = valX/oldInt * newInt;
	return res;
}