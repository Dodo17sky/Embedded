/*
 * ShiftRegister.h
 *
 * Created: 12/6/2015 12:52:06 PM
 *  Author: Dodo
 */ 


#ifndef SHIFTREGISTER_H_
#define SHIFTREGISTER_H_


/************************************
*     SHIFT REGISTER variables      *
*************************************/
#define      _DOT    -128
#define DIGIT_ZERO   0b10000001
#define DIGIT_ONE    0b11001111
#define DIGIT_TWO    0b10010010
#define DIGIT_THREE  0b10000110
#define DIGIT_FOUR   0b11001100
#define DIGIT_FIVE   0b10100100
#define DIGIT_SIX    0b10100000
#define DIGIT_SEVEN  0b10001111
#define DIGIT_EIGHT  0b10000000
#define DIGIT_NINE   0b10000100
#define DIGIT_A      0b10001000
#define DIGIT_B      0b11100000
#define DIGIT_C      0b10110001
#define DIGIT_D      0b11000010
#define DIGIT_E      0b10110000
#define DIGIT_F      0b10111000
#define DIGIT_MINUS  0b11111110

char  digit[17];

struct ShiftRegister
{
	volatile uint8_t *reg;
	uint8_t         DATAIN;
	uint8_t         CLOCK;
	uint8_t         LATCH;
	uint8_t         state;
};

struct ShiftRegister initShiftRegister(volatile uint8_t *reg, uint8_t datain, uint8_t clock, uint8_t latch);

void shift_HIGH        (struct ShiftRegister sh);
void shift_LOW         (struct ShiftRegister sh);
void shiftByte_noLatch (struct ShiftRegister sh, uint8_t value);
void shiftByte         (struct ShiftRegister sh, uint8_t value);
void latch_LOW         (struct ShiftRegister sh);
void latch_HIGH        (struct ShiftRegister sh);
void initDigits        ();

#endif /* SHIFTREGISTER_H_ */