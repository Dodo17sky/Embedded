/*
 * ShiftRegister_library.c
 *
 * Created: 12/6/2015 12:50:41 PM
 * Author : Dodo
 */ 

#include <avr/io.h>
#include "ShiftRegister.h"

struct ShiftRegister initShiftRegister(volatile uint8_t *reg, uint8_t datain, uint8_t clock, uint8_t latch)
{
	struct ShiftRegister newSH;
	
	newSH.reg     = reg;
	newSH.DATAIN  = datain;
	newSH.CLOCK   = clock;
	newSH.LATCH   = latch;
	newSH.state   = 0x00;
	
	// set shift register pins as OUTPUT
	*newSH.reg |= (1<<newSH.DATAIN);
	*newSH.reg |= (1<<newSH.CLOCK);
	*newSH.reg |= (1<<newSH.LATCH);
	
	return newSH;
}

void shift_HIGH(struct ShiftRegister sh)
{
	volatile uint8_t *  PORTx = (++sh.reg);
	*PORTx &= ~(1<<sh.CLOCK);  // CLOCK low
	*PORTx |=  (1<<sh.DATAIN); // next Shift Register pin will be HIGH
	*PORTx |=  (1<<sh.CLOCK);  // CLOCK high
}

void shift_LOW (struct ShiftRegister sh)
{
	volatile uint8_t *  PORTx = (++sh.reg);
	*PORTx &= ~(1<<sh.CLOCK);  // CLOCK low
	*PORTx &= ~(1<<sh.DATAIN); // next Shift Register pin will be LOW
	*PORTx |=  (1<<sh.CLOCK);  // CLOCK high
}

void shiftByte (struct ShiftRegister sh, uint8_t value)
{
	uint8_t i = 0;
	volatile uint8_t *  PORTx = (++sh.reg);
	
	*PORTx &= ~(1<<sh.LATCH);  // LATCH low
	for( i=0; i<8; i++)
	{
		if( (value&(1<<i)) )
		{
			*PORTx &= ~(1<<sh.CLOCK);  // CLOCK low
			*PORTx |=  (1<<sh.DATAIN); // next Shift Register pin will be HIGH
			*PORTx |=  (1<<sh.CLOCK);  // CLOCK high
		}
		else
		{
			*PORTx &= ~(1<<sh.CLOCK);  // CLOCK low
			*PORTx &= ~(1<<sh.DATAIN); // next Shift Register pin will be LOW
			*PORTx |=  (1<<sh.CLOCK);  // CLOCK high
		}
	}
	*PORTx |= (1<<sh.LATCH);  // LATCH high
}

void shiftByte_noLatch (struct ShiftRegister sh, uint8_t value)
{
	uint8_t i = 0;
	volatile uint8_t *  PORTx = (++sh.reg);
	
	for( i=0; i<8; i++)
	{
		if( (value&(1<<i)) )
		{
			*PORTx &= ~(1<<sh.CLOCK);  // CLOCK low
			*PORTx |=  (1<<sh.DATAIN); // next Shift Register pin will be HIGH
			*PORTx |=  (1<<sh.CLOCK);  // CLOCK high
		}
		else
		{
			*PORTx &= ~(1<<sh.CLOCK);  // CLOCK low
			*PORTx &= ~(1<<sh.DATAIN); // next Shift Register pin will be LOW
			*PORTx |=  (1<<sh.CLOCK);  // CLOCK high
		}
	}
}

void latch_LOW (struct ShiftRegister sh)
{
	volatile uint8_t *  PORTx = (++sh.reg);
	*PORTx &= ~(1<<sh.LATCH);  // LATCH low
}

void latch_HIGH(struct ShiftRegister sh)
{
	volatile uint8_t *  PORTx = (++sh.reg);
	*PORTx |= (1<<sh.LATCH);  // LATCH high
}

void initDigits()
{
	digit[0]  = DIGIT_ZERO;
	digit[1]  = DIGIT_ONE;
	digit[2]  = DIGIT_TWO;
	digit[3]  = DIGIT_THREE;
	digit[4]  = DIGIT_FOUR;
	digit[5]  = DIGIT_FIVE;
	digit[6]  = DIGIT_SIX;
	digit[7]  = DIGIT_SEVEN;
	digit[8]  = DIGIT_EIGHT;
	digit[9]  = DIGIT_NINE;
	digit[10] = DIGIT_A;
	digit[11] = DIGIT_B;
	digit[12] = DIGIT_C;
	digit[13] = DIGIT_D;
	digit[14] = DIGIT_E;
	digit[15] = DIGIT_F;
	digit[16] = DIGIT_MINUS;
}

