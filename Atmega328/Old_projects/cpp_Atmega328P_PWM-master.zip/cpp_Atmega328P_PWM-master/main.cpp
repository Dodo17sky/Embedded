/*
 * cpp_Atmega328P_PWM.cpp
 *
 * Created: 12/22/2015 1:42:49 PM
 * Author : Dodo
 */ 

#define F_CPU 1000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "pwm.h"

void pwm_test_0();
void pwm_test_1();

int main(void)
{
	pwm_test_0();
}

void pwm_test_0()
{
	Timer0 tm0;
	
	tm0.setFastPWM_mode3();
	tm0.enableOutPinA();
	tm0.enableOutPinB();
	tm0.setPrescaler(FCPU_1);
	
	int i =0;
	
	while(1)
	{
		for(i=0;i <256; i++)
		{
			tm0.setPWM_A(i);
			tm0.setPWM_B(i);
			_delay_ms(10);
		}
		_delay_ms(2000);
				
		for(i=255;i>=0; i--)
		{
			tm0.setPWM_A(i);
			tm0.setPWM_B(i);
			_delay_ms(10);
		}
		_delay_ms(2000);
	}
}

void pwm_test_1()
{
	Timer0 tm0;
	
	tm0.setFastPWM_mode3();
	tm0.enableOutPinA();
	tm0.enableOutPinB();
	tm0.setPrescaler(FCPU_1);
	
	int i =0;
	
	while(1)
	{
		for(i=0;i <256; i++)
		{
			tm0.setPWM_A(i);
			tm0.setPWM_B(i);
			_delay_ms(10);
		}
		
		for(i=255;i>=0; i--)
		{
			tm0.setPWM_A(i);
			tm0.setPWM_B(i);
			_delay_ms(10);
		}
	}
}
