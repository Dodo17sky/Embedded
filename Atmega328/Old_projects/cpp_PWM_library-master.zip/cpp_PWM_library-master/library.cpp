/*
 * cpp_PWM_library.cpp
 *
 * Created: 12/22/2015 1:39:32 PM
 * Author : Dodo
 */ 

#include <avr/io.h>
#include "pwm.h"

void Timer0::setFastPWM_mode3(){
	TCCR0A |= (1<<WGM00);
	TCCR0A |= (1<<WGM01);
	TCCR0A |= (1<<COM0A1);
	TCCR0A |= (1<<COM0B1);
}

void Timer0::enableOutPinA(){
	DDRD |= (1<<PORTD6);
}

void Timer0::enableOutPinB(){
	DDRD |= (1<<PORTD5);
}

void Timer0::setPWM_A(uint8_t dutyCycle){
	OCR0A = dutyCycle;
}

void Timer0::setPWM_B(uint8_t dutyCycle){
	OCR0B = dutyCycle;
}

void Timer0::setPrescaler(uint8_t prescaler){
	TCCR0B |= prescaler;
}