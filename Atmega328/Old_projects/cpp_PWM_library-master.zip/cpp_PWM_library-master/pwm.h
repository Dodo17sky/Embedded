/*
 * pwm.h
 *
 * Created: 12/22/2015 1:40:04 PM
 *  Author: Dodo
 */ 


#ifndef PWM_H_
#define PWM_H_

class Timer0{
	
	public:
			void setFastPWM_mode3();
			void enableOutPinA();
			void enableOutPinB();
			void setPWM_A(uint8_t dutyCycle);
			void setPWM_B(uint8_t dutyCycle);
#define FCPU_1      1   //  001
#define FCPU_8      2   //  010
#define FCPU_64     3   //  011
#define FCPU_256    4   //  100
#define FCPU_1024   5   //  101
			void setPrescaler(uint8_t prescaler);
};

#endif /* PWM_H_ */