/*
 * util_library.c
 *
 * Created: 12/21/2015 6:25:14 PM
 * Author : Dodo
 */ 

#include <avr/io.h>
#include "util.h"