/*
 * util.h
 *
 * Created: 12/21/2015 6:25:43 PM
 *  Author: Dodo
 */ 


#ifndef UTIL_H_
#define UTIL_H_

#define setB(x,y)    x |=  (1<<y)
#define clrB(x,y)    x &= ~(1<<y)
#define  isH(x,y)    x & (1<<y)  ? true : false
#define  isL(x,y)   ~x & (1<<y)  ? true : false


#endif /* UTIL_H_ */